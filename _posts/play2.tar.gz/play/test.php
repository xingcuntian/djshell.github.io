<?php



$m = new \adf();
//$m->set('param1','param2');
//var_dump($m->param1);
//echo("================================");

//$m->set('testparam1');
//var_dump($m->get());

//echo("===============================");
//var_dump($m->param1);
//

$n = new \udf();
var_dump($n->get());
//dump_class_table();
